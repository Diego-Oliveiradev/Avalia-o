package br.com.senac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.senac.dominio.OrdemServico;
import br.com.senac.dominio.Recurso;
import br.com.senac.servico.OrdemServicoService;
import br.com.senac.servico.RecursoService;
import br.com.senac.servico.exception.ObjectNotFoundException;

@Controller
@RequestMapping("/ordemServico")
public class OrdemServicoController {

	@Autowired
	private OrdemServicoService ordemServicoService;	
	
	@GetMapping("/listaOrdemServico")
	public ModelAndView listaOrdemServico() {
		ModelAndView mv = new ModelAndView("recurso/paginaOrdemServicoa");
		mv.addObject("ordemServicos", ordemServicoService.listaOrdemServico());
		return mv;
	}
	
	@GetMapping("/adicionarOrdemServico")
	public ModelAndView add() {
		ModelAndView mv = new ModelAndView("recurso/paginaAdicionarOrdemServico");
		mv.addObject("ordemServico", new OrdemServico());
		return mv;
	}		

	@PostMapping("/salvarOrdemServico")
	public ModelAndView inserir(br.com.senac.dominio.OrdemServico ordemServico) {
		ordemServicoService.inserir(ordemServico);
		return listaOrdemServico();
	}
		
	
	
	
}
