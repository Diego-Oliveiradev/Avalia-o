package br.com.senac.inicializacao;


import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import br.com.senac.dominio.OrdemServico;
import br.com.senac.dominio.Recurso;
import br.com.senac.dominio.Usuario;
import br.com.senac.repositorio.RecursoRepositorio;
import br.com.senac.repositorio.UsuarioRepositorio;;

public class Init implements ApplicationListener<ContextRefreshedEvent>{
	
	
	@Autowired
	UsuarioRepositorio usuarioRepositorio;
	
	@Autowired
	RecursoRepositorio recursoRepositorio;	
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		
		Usuario usuario1 = new Usuario();
		usuario1.setNome("Lucas");
		usuario1.setCpf("12345678912");
		usuario1.setSenha("12345678");
		
		Usuario usuario2 = new Usuario();
		usuario2.setNome("Diego");
		usuario2.setCpf("12345678912");
		usuario2.setSenha("12345678");
		
		Usuario usuario3 = new Usuario();
		usuario3.setNome("Andressa");
		usuario3.setCpf("12345678912");
		usuario3.setSenha("12345678");		
		
		usuarioRepositorio.save(usuario1);
		usuarioRepositorio.save(usuario2);
		usuarioRepositorio.save(usuario3);


		Recurso recurso1 = new Recurso();
		recurso1.setNome("Conector Rj-45");
		recurso1.setDescricao("Conector de RJ-45 para internet");
		recurso1.setCusto(1.00);
		
		Recurso recurso2 = new Recurso();
		recurso2.setNome("Fio para Internet");
		recurso2.setDescricao("Fio para Internet de prédios");
		recurso2.setCusto(10.00);
		
		Recurso recurso3 = new Recurso();
		recurso3.setNome("Roteador TC50");
		recurso3.setDescricao("Roteador wi-fi");
		recurso3.setCusto(1.00);		
		
		
		recursoRepositorio.save(recurso1);
		recursoRepositorio.save(recurso1);
		recursoRepositorio.save(recurso1);		
		
		OrdemServico ordemServico1 = new OrdemServico();
		ordemServico1.setNome("Instalação Roteador");
		ordemServico1.setDescricao("Instalação Roteador na sala 703");
		//ordemServico1.setDataInicio("2019-05-14");		
		//ordemServico1.setDataFim("20190514");	
		

		
	}

}
