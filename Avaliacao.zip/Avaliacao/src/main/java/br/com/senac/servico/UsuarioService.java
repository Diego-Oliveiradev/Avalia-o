package br.com.senac.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import br.com.senac.dominio.Usuario;
import br.com.senac.repositorio.UsuarioRepositorio;
import br.com.senac.servico.exception.ObjectNotFoundException;

@Service
public class UsuarioService {
	
	@Autowired
	private UsuarioRepositorio repoCat;
	
	public Usuario buscar(Integer id) {
		Optional<Usuario> objUsuario = repoCat.findById(id);
		return  objUsuario.orElseThrow(null);
	}
	
	public Usuario inserir(Usuario objUsuario) {
		objUsuario.setId(null);
		return repoCat.save(objUsuario);
	}
	
	public Usuario alterar(Usuario objUsuario) {
		Usuario objUsuarioEncontrado = buscar(objUsuario.getId());
		objUsuarioEncontrado.setNome(objUsuario.getNome());
		objUsuarioEncontrado.setCpf(objUsuario.getCpf());
		objUsuarioEncontrado.setSenha(objUsuario.getSenha());
		return repoCat.save(objUsuario);
	}
	
	public void excluir(Integer id) {
		repoCat.deleteById(id);
	}
	
	public List<Usuario> listaUsuario() {
		return repoCat.findAll();
	
	}
	
}
