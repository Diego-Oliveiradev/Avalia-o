package br.com.senac.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.senac.dominio.Recurso;
import br.com.senac.repositorio.RecursoRepositorio;
import br.com.senac.servico.exception.ObjectNotFoundException;


@Service
public class RecursoService {

	@Autowired
	private RecursoRepositorio repoCat;	
	
	public Recurso buscar(Integer id) {
		Optional<Recurso> objRecurso = repoCat.findById(id);	
		//return objRecurso.orElseThrow((() -> new ObjectNotFoundException("Recurso não encontrado! recurso_id: "+id+", Tipo: "+Recurso.class.getName())));	
		return  objRecurso.orElseThrow(null);
	}
	
	

	
		public Recurso inserir(Recurso objRecurso) {
			objRecurso.setId(null);
			return repoCat.save(objRecurso);
		
		}	
		
	
		public Recurso alterar(Recurso objRecurso) {
			Recurso objRecursoEncontrado = buscar(objRecurso.getId());
			objRecursoEncontrado.setNome(objRecurso.getNome());
			objRecursoEncontrado.setDescricao(objRecurso.getDescricao());
			objRecursoEncontrado.setCusto(objRecurso.getCusto());
			return repoCat.save(objRecurso);
		}		
	

		public void excluir(Integer id) {
			repoCat.deleteById(id);
		}
		
		public List<Recurso> listaRecurso() {
			return repoCat.findAll();
		
		}
		
}

