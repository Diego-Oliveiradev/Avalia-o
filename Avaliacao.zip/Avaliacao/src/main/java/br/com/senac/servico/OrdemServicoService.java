package br.com.senac.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.senac.dominio.OrdemServico;
import br.com.senac.repositorio.OrdemServicoRepositorio;
import br.com.senac.servico.exception.ObjectNotFoundException;

@Service
public class OrdemServicoService {

	@Autowired
	private OrdemServicoRepositorio repoCat;
	
	public OrdemServico buscar(Integer id) {
		Optional<OrdemServico> objOrdemServico = repoCat.findById(id);
		return  objOrdemServico.orElseThrow(null);
	}
	
	public OrdemServico inserir(OrdemServico objOrdemServico) {
		objOrdemServico.setId(null);
		return repoCat.save(objOrdemServico);
	}	
	
	public OrdemServico alterar(OrdemServico objOrdemServico) {
		OrdemServico objOrdemServicoEncontrado = buscar(objOrdemServico.getId());
		objOrdemServico.setNome(objOrdemServico.getNome());
		objOrdemServico.setDescricao(objOrdemServico.getDescricao());
		objOrdemServico.setDataInicio(objOrdemServico.getDataInicio());
		objOrdemServico.setDataFim(objOrdemServico.getDataFim());		
		return repoCat.save(objOrdemServico);
	}	
	
	public void excluir(Integer id) {
		repoCat.deleteById(id);
	}
	
	public List<OrdemServico> listaOrdemServico() {
		return repoCat.findAll();
	
	}	
	
}
