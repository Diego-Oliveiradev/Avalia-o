package br.com.senac.servico.exception;

public class ObjectNotFoundException {

}
