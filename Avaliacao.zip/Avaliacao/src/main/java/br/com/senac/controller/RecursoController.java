package br.com.senac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.senac.dominio.Recurso;
import br.com.senac.dominio.Usuario;
import br.com.senac.servico.RecursoService;
import br.com.senac.servico.exception.ObjectNotFoundException;

@Controller
@RequestMapping("/recurso")
public class RecursoController {
	
	@Autowired
	private RecursoService recursoService;	
	
	@GetMapping("/listaRecurso")
	public ModelAndView listaRecursos() {
		ModelAndView mv = new ModelAndView("recurso/paginaRecursos");
		mv.addObject("recursos", recursoService.listaRecurso());
		return mv;
	}
	
	
	@GetMapping("/adicionarRecurso")
	public ModelAndView add() {
		ModelAndView mv = new ModelAndView("recurso/paginaAdicionarRecurso");
		mv.addObject("recurso", new Recurso());
		return mv;
	}	
	
	@PostMapping("/salvarRecurso")
	public ModelAndView inserir(br.com.senac.dominio.Recurso recurso) {
		recursoService.inserir(recurso);
		return listaRecursos();
	}
	
	@GetMapping("/excluirRecurso/{id}")
	   public ModelAndView delete(@PathVariable("id") Integer id) {
			recursoService.excluir(id);
			return listaRecursos();
		}		

	@GetMapping("/alterarRecurso/{id}")
	public ModelAndView alterar(@PathVariable("id") Integer id) //throws ObjectNotFoundException
	{
		ModelAndView mv = new ModelAndView("recurso/paginaAlterar");
		mv.addObject("recurso", recursoService.buscar(id));
		return mv;
	}	
	
	@PostMapping("/alterar")
	public ModelAndView alterar(Recurso recurso) {
		recursoService.alterar(recurso);
		return listaRecursos();
	}		
	
}
