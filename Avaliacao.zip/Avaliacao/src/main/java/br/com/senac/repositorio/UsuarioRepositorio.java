package br.com.senac.repositorio;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.com.senac.dominio.Recurso;
import br.com.senac.dominio.Usuario;

@Repository
public interface UsuarioRepositorio extends JpaRepository<Usuario, Integer> {
	
	@Query("select a from Usuario a where a.nome=?1")
	Usuario findByNome(String nome);
	
	Optional<Usuario> findById(Integer id);
	

}


/* extends JpaRepository<Aluno, Integer>*/