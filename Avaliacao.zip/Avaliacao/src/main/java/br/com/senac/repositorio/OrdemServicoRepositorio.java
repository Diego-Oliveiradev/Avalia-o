package br.com.senac.repositorio;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.com.senac.dominio.OrdemServico;
import br.com.senac.dominio.Recurso;
@Repository
public interface OrdemServicoRepositorio extends JpaRepository<OrdemServico, Integer> {
	
	@Query("select a from OrderServico a where a.nome=?1")
	OrdemServico findBYNome(String nome);
	
	@Query("select a from OrderServico a where a.nome=?1")
	OrdemServico findByNome(String dataFim);	
	
	Optional<OrdemServico> findById(Integer id);
	

}
