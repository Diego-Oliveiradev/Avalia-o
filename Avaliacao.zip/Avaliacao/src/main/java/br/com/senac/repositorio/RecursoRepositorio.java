package br.com.senac.repositorio;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.com.senac.dominio.OrdemServico;
import br.com.senac.dominio.Recurso;;

@Repository
public interface RecursoRepositorio extends JpaRepository<Recurso, Integer>{

	@Query("select a from Recurso a where a.nome=?1")
	Recurso findByNome(String nome);

	Optional<Recurso> findById(Integer id);

	
}
