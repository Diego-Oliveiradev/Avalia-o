package br.com.senac.dominio;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class OrdemServico implements Serializable {
	
	private static final long serialVersionUID = 1L;	
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
   // @Column(name = "orderServiso_id")		
	private Integer id;
	
	private String nome;
	private String descricao;
	private Date dataInicio;
	private Date dataFim;
	
	@JsonIgnore
	@OneToOne
	//@JoinColumn(name="usuario_id",  referencedColumnName = "usuario_id")
	//private Usuario usuario;
	private List<Usuario> usuario = new ArrayList<>();
	
	@ManyToOne
	//@JoinTable(name="ORDEM_RECURSO", joinColumns = @JoinColumn(name="orderServiso_id"),  inverseJoinColumns = @JoinColumn(name="recurso_id"))
	private List<Recurso> recurso = new ArrayList<>();

	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}


	public List<Usuario> getUsuario() {
		return usuario;
	}

	public void setUsuario(List<Usuario> usuario) {
		this.usuario = usuario;
	}

	public List<Recurso> getRecurso() {
		return recurso;
	}

	public void setRecurso(List<Recurso> recurso) {
		this.recurso = recurso;
	}

	public OrdemServico(Integer id, String nome, String descricao, Date dataInicio, Date dataFim) {
		super();
		this.id = id;
		this.nome = nome;
		this.descricao = descricao;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
	}

	public OrdemServico() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	//public Usuario getUsuario() {
	//	return usuario;
	//}

	//public void setUsuario(Usuario usuario) {
	//	this.usuario = usuario;
	//}


	
}


/*


Usua
abertura
usuario 
data de fechamento
descricao
nome
recurso

*/